package com.coursecampus.athleteconnect.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Fitness/Sports Theme
val FitnessPrimary = Color(0xFF2E7D32) // Deep Green
val FitnessPrimaryVariant = Color(0xFF1B5E20) // Darker Green
val FitnessSecondary = Color(0xFFFF6F00) // Orange
val FitnessSecondaryVariant = Color(0xFFE65100) // Dark Orange

// Surface Colors
val FitnessSurface = Color(0xFFFFFBFE)
val FitnessSurfaceVariant = Color(0xFFF3F3F3)
val FitnessBackground = Color(0xFFFFFBFE)

// Text Colors
val FitnessOnPrimary = Color(0xFFFFFFFF)
val FitnessOnSecondary = Color(0xFFFFFFFF)
val FitnessOnSurface = Color(0xFF1C1B1F)
val FitnessOnBackground = Color(0xFF1C1B1F)

// Status Colors
val FitnessSuccess = Color(0xFF4CAF50)
val FitnessWarning = Color(0xFFFF9800)
val FitnessError = Color(0xFFF44336)
val FitnessInfo = Color(0xFF2196F3)

// Accent Colors
val FitnessGold = Color(0xFFFFD700)
val FitnessSilver = Color(0xFFC0C0C0)
val FitnessBronze = Color(0xFFCD7F32)

// Dark Theme Colors
val FitnessPrimaryDark = Color(0xFF4CAF50)
val FitnessPrimaryVariantDark = Color(0xFF2E7D32)
val FitnessSecondaryDark = Color(0xFFFFB74D)
val FitnessSecondaryVariantDark = Color(0xFFFF8F00)

val FitnessSurfaceDark = Color(0xFF1C1B1F)
val FitnessSurfaceVariantDark = Color(0xFF2B2B2B)
val FitnessBackgroundDark = Color(0xFF121212)

val FitnessOnPrimaryDark = Color(0xFF000000)
val FitnessOnSecondaryDark = Color(0xFF000000)
val FitnessOnSurfaceDark = Color(0xFFE6E1E5)
val FitnessOnBackgroundDark = Color(0xFFE6E1E5)

// Gradient Colors
val GradientStart = Color(0xFF2E7D32)
val GradientEnd = Color(0xFF4CAF50)
val GradientSecondaryStart = Color(0xFFFF6F00)
val GradientSecondaryEnd = Color(0xFFFFB74D)

// Chart Colors
val ChartColor1 = Color(0xFF2E7D32)
val ChartColor2 = Color(0xFFFF6F00)
val ChartColor3 = Color(0xFF2196F3)
val ChartColor4 = Color(0xFF9C27B0)
val ChartColor5 = Color(0xFFF44336)